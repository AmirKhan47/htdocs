<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Lead extends CI_Controller {

	public function __construct(){
		parent::__construct();
		//Do your magic here
		$this->load->model('ro/Lead_model','lead_model');
		$this->load->model('Auth_model');
	}

	public function new_leads(){
		$check=$this->Auth_model->Auth();
		if($check['status']==200){
			$data['sublayout']='ro/leads/new_leads';
			$data['active']='new_leads';
			$this->load->view('ro/ro_layout',$data);


		}else{
			$this->session->set_flashdata('err_message',$check['message']);
			redirect(URL.'Auth/');
		}

	}

	public function get_newlead(){
		$list=$this->lead_model->get_newleads();
		$data = array();
		$no = $_POST['start'];

		foreach ($list as $key => $value) {
			$no++;
			$row = array();

			$action='<a href="#" class="btn btn-success"><i class="fa fa-check"></i></a>';
			
			$row[] = $value['id'];
			$row[] = $value['name'];
			$row[] = $value['phone'];
			$row[] = $value['address'];
			$row[] = $value['bdm'];
			$row[] = $action;
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->lead_model->newlead_count(),
			"recordsFiltered" => $this->lead_model->newlead_count(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);
	}
}

/* End of file Lead.php */
/* Location: ./application/controllers/bdm/Lead.php */
?>