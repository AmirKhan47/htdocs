<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Leads extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('admin/Auth_model');
		$this->load->model('admin/Leads_model');
		//Do your magic here
	}

	public function new_lead(){
		$check=$this->Auth_model->Auth();
		if($check['status']==200){
			$data['sublayout']='admin/leads/new_leads';
			$where=array('role' => 2,);
			$data['ro'] = $this->Mod_common->select_array_records('users',$where);
			
			$data['active'] ='new_lead';
			$this->load->view('admin/admin_layout',$data);
		}else{
			$this->session->set_flashdata('err_message',$check['message']);
			redirect(AURL.'auth/');
		}

	}

	public function get_newlead(){
		$list=$this->Leads_model->get_newlead();
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $key => $value) {
			$no++;
			$row = array();
			$color='';
			if($value['Name'] !=''){
				$action ='<a href="#" class="btn btn-info"><i class="fa fa-eye"></i>
				</a>';

			}else{
				$action ='<a href="#" class="btn btn-info"><i class="fa fa-eye"></i></a>
			          <a onclick="assignmodal('.$value['id'].')" class="btn btn-success"><i class="fa fa-check-square-o"></i></a>';
			}

			

			$fields='<input type="hidden" id="lead_'.$value['id'].'" value="'.$value['id'].'"/>
			         <input type="hidden" id="name_'.$value['id'].'" value="'.$value['name'].'"/>
			         <input type="hidden" id="designation_'.$value['id'].'" value="'.$value['designation'].'"/>
			         <input type="hidden" id="phone_'.$value['id'].'" value="'.$value['phone'].'"/>';
			
			if($value['priority']==1){
				//red
				$color='<div class="col-md-2"><div style="width: 2vw; height: 2vw; border: 1.5px solid black; border-radius: 60%; background: #ff4d4d;left:25%;position: relative;"></div></div>';
			}elseif ($value['priority']==2) { 
				//green
				$color='<div class="col-md-2"><div style="width: 2vw; height: 2vw; border: 1.5px solid black; border-radius: 50%; background: #00b300;left:25%;position: relative;"></div></div>';
			}elseif ($value['priority']==3) {
				//blue
				$color='<div class="col-md-2"><div style="width: 2vw; height: 2vw; border: 1.5px solid black; border-radius: 50%; background: #6666ff;left:25%;position: relative;"></div></div>';
			}elseif ($value['priority']==4) {
				//white
				$color='<div class="col-md-2"><div style="width: 2vw; height: 2vw; border: 1.5px solid black; border-radius: 50%;left:25%;position: relative;"></div></div>';
			}
			//status
			if($value['stage_name']=='Registered'){
				$status='<span class="label label-default">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Unchecked') {
				$status='<span class="label label-warning">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Visit') {
				$status='<span class="label label-info">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Work in progress') {
				$status='<span class="label label-info">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Review') {
				$status='<span class="label label-info">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Presentation') {
				$status='<span class="label label-info">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Success') {
				$status='<span class="label label-success">'.$value['stage_name'].'</span>';
			}elseif ($value['stage_name']=='Fail') {
				$status='<span class="label label-danger">'.$value['stage_name'].'</span>';
			}


			$row[] = $value['id'].$fields;
			$row[] = $value['name'];
			$row[] = $value['designation'];
			$row[] = $value['phone'];
			$row[] = $value['Name'];
			$row[] = $color;
			$row[] = $status;
			$row[] = $action;
			$data[] = $row;

		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Leads_model->newlead_count(),
			"recordsFiltered" => $this->Leads_model->newlead_count(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);


	}

	public function assign_ro(){
		$check=$this->Auth_model->Auth();
		if($check['status']==200){
			if($this->input->post('submit')){
				$lead_id=$this->input->post('lead_id');
				$assign_ro=$this->input->post('ro_list');
				$created_date=date('Y-m-d H:i:s');
				$created_by=$this->session->userdata('user_id');

				$insert_array=array(
					'lead_id' => $lead_id,
					'assign_ro' => $assign_ro,
					'created_date' => $created_date,
					'created_by' => $created_by,
					'is_read' => 0,
				);
				$insert=$this->Mod_common->insert_into_table('assign',$insert_array);
				if($insert){
					$assign_id=$this->db->insert_id();
					$where=array('id'=>$lead_id);
					$search=$this->Mod_common->select_single_records('customer_leads',$where);
					if($search){
						$where=array('id'=> $search['stage_id'],);
						$update_array=array(
							'end_date' => $created_date,
							'result' =>1,
						);

						$update=$this->Mod_common->update_table('stage',$where,$update_array);
						if($update){
							$insert_array=array(
								'lead_id' => $lead_id,
								'assign_id' => $assign_id,
								'stage_name_id' => 2,
								'created_date' => $created_date,
								
							);
							$insert=$this->Mod_common->insert_into_table('stage',$insert_array);
							if($insert){
								$stage_id=$this->db->insert_id();
								$update_array=array('stage_id' => $stage_id,);
								$where=array('id' =>$lead_id);
								$update=$this->Mod_common->update_table('customer_leads',$where,$update_array);
								if($update){
									$this->session->set_flashdata('ok_message', '- RO Assign successfully');
									redirect(AURL.'leads/new_lead');
								}else{
									$this->session->set_flashdata('err_message', '- Error in assigning RO');
									redirect(AURL.'leads/new_lead');
								}

							}

						}
					}
				}

			}

		}else{
			$this->session->set_flashdata('err_message',$check['message']);
			redirect(AURL.'auth/');
		}
	}

	public function all_leads(){
		$check=$this->Auth_model->Auth();
		if($check['status']==200){
			$data['sublayout']='admin/leads/all_leads';		
			$data['active'] ='all_leads';
			$this->load->view('admin/admin_layout',$data);
		}else{
			$this->session->set_flashdata('err_message',$check['message']);
			redirect(AURL.'auth/');
		}
		
	}

	public function get_allleads(){
		$list=$this->Leads_model->get_allleads();
		// printme($list);exit;
		$data = array();
		$no = $_POST['start'];
		foreach ($list as $key => $value) {
			$no++;
			$row = array();

			$action ='<a href="#" class="btn btn-info"><i class="fa fa-eye"></i>
				</a>';
			$row[] = $value['id'];
			$row[] = $value['name'];
			$row[] = $value['designation'];
			$row[] = $value['phone'];
			$row[] = $value['ro'];
			$row[] = $value['bdm'];
			//status
			if($value['status']=='Registered'){
				$status='<span class="label label-default">'.$value['status'].'</span>';
			}elseif ($value['status']=='Unchecked') {
				$status='<span class="label label-warning">'.$value['status'].'</span>';
			}elseif ($value['status']=='Visit') {
				$status='<span class="label label-info">'.$value['status'].'</span>';
			}elseif ($value['status']=='Work in progress') {
				$status='<span class="label label-info">'.$value['status'].'</span>';
			}elseif ($value['status']=='Review') {
				$status='<span class="label label-info">'.$value['status'].'</span>';
			}elseif ($value['status']=='Presentation') {
				$status='<span class="label label-info">'.$value['status'].'</span>';
			}elseif ($value['status']=='Success') {
				$status='<span class="label label-success">'.$value['status'].'</span>';
			}elseif ($value['status']=='Fail') {
				$status='<span class="label label-danger">'.$value['status'].'</span>';
			}

			//final status
			if($value['final_status']==1){
				$final_status = '<span class="label label-primary">Pending</span>';
			}elseif ($value['final_status']==2) {
				$final_status = '<span class="label label-success">Close</span>';
			}elseif ($value['final_status']==3) {
				$final_status = '<span class="label label-danger">Failure</span>';
			}

			$row[]=$status;
			$row[]=$final_status;
			$row[] = $action;
			$data[] = $row;
		}
		$output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->Leads_model->newlead_count(),
			"recordsFiltered" => $this->Leads_model->newlead_count(),
			"data" => $data,
		);
        //output to json format
		echo json_encode($output);

	}
	

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/bdm/Dashboard.php */

?>