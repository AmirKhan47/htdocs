<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->model('admin/Auth_model');
		//Do your magic here
	}

	public function index(){
		$check=$this->Auth_model->Auth();
		if($check['status']==200){
			
			$data['sublayout']='admin/dashboard/dashboard';
			$data['active']='dashboard';
			$this->load->view('admin/admin_layout',$data);
			
		}else{
			$this->session->set_flashdata('err_message',$check['message']);
			redirect(AURL.'auth/');
		}
		
	}

}

/* End of file Dashboard.php */
/* Location: ./application/controllers/bdm/Dashboard.php */

?>