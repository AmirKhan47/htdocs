
        <div class="page-footer">
            <div class="page-footer-inner"> Oppein - CRM
                
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->
        
        <script src="<?php echo Assets;?>global/plugins/respond.min.js"></script>
        <script src="<?php echo Assets;?>global/plugins/excanvas.min.js"></script> 

        <script src="<?php echo Assets;?>global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <script src="<?php echo Assets;?>global/scripts/datatable.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo Assets;?>global/scripts/app.min.js" type="text/javascript"></script>
        <!-- <script src="<?php echo Assets;?>pages/scripts/table-datatables-colreorder.min.js" type="text/javascript"></script> -->
        <script src="<?php echo Assets;?>pages/scripts/components-date-time-pickers.min.js" type="text/javascript"></script>

        
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        
        
        <script src="<?php echo Assets;?>layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <script src="<?php echo Oppeinscript;?>leads-datatable.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>pages/scripts/registration-validation.js" type="text/javascript"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script> -->
        <!-- END THEME LAYOUT SCRIPTS-->
        <script type="text/javascript">
            $('#date').datepicker({ dateFormat: 'dd-mm-yy' });
        </script>
        
        
        