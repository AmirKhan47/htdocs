<!-- BEGIN PAGE BAR -->
<div class="page-bar">
    <ul class="page-breadcrumb">
        <li>
            
            <i class="fa fa-circle"></i>
        </li>
        <li>
            <a href="<?php echo BURL.'Dashboard/'?>">Dashboard</a>
            
        </li>
        
    </ul>
    
</div>
<!-- END PAGE BAR -->
<!-- BEGIN PAGE TITLE-->
<h3 class="page-title"> Dashboard
    
</h3>
<!-- END PAGE TITLE-->
<!-- END PAGE HEADER-->
<div class="note note-info">
    <p>Coming Soon</p>
</div>