BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2014 &copy; Metronic by keenthemes.
                <a href="http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes" title="Purchase Metronic just for 27$ and get lifetime updates for free" target="_blank">Purchase Metronic!</a>
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- END FOOTER -->
        
        <script src="<?php echo Assets;?>global/plugins/respond.min.js"></script>
        <script src="<?php echo Assets;?>global/plugins/excanvas.min.js"></script> 

        <script src="<?php echo Assets;?>global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/uniform/jquery.uniform.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        
        <script src="<?php echo Assets;?>global/scripts/app.min.js" type="text/javascript"></script>
        
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo Assets;?>layouts/layout/scripts/layout.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>layouts/layout/scripts/demo.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
        <script src="<?php echo Assets;?>pages/scripts/validation.js" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS