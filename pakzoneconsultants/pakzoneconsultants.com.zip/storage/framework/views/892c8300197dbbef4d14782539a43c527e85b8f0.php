<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Add
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">General Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Horizontal Form</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            
                
                <div class="box-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session()->get('success')); ?>  
                        </div><br />
                    <?php endif; ?>
                    
                    <?php if($images != NULL): ?>
                        <div class="row">
                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="card">
                                        <img height="100%" width="100%" src="<?php echo e(URL); ?>uploads/slider_images/<?php echo e($image['image_name']); ?>" alt="">
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <br>

                    <div class="row">

                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('admin.store')); ?>" id="">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="file_slide_one">Slider Image 1</label>
                                    <input type="file" name="image1" id="">
                                </div>
                                <button id="slide_one_upload_btn" type="submit" name="submit" value="submit" class="btn bg-green">
                                    Update
                                </button>
                            </form>
                        </div>

                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('admin.store')); ?>" id="">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="file_slide_one">Slider Image 1</label>
                                    <input type="file" name="image2" id="">
                                </div>
                                <button id="slide_one_upload_btn" type="submit" name="submit" value="submit" class="btn bg-green">
                                    Update
                                </button>
                            </form>
                        </div>

                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('admin.store')); ?>" id="">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="file_slide_one">Slider Image 1</label>
                                    <input type="file" name="image3" id="">
                                </div>
                                <button id="" type="submit" name="submit" value="submit" class="btn bg-green">
                                    Update
                                </button>
                            </form>
                        </div>

                        

                    </div>

                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <button type="submit" class="btn btn-info pull-right">Submit</button>
                </div>
                <!-- /.box-footer -->
            
          </div>
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>