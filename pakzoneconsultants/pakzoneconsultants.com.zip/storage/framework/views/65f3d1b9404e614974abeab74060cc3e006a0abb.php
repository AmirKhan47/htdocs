<?php $__env->startSection('title'); ?>
<?php $__env->startSection('content'); ?>

	<!--######## start banner Area ########-->
	
	<section class="" id="">
	  	<div class="bd-example">
		  	<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
		    <ol class="carousel-indicators">
		      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
		      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
		      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
		    </ol>
		    <div class="carousel-inner">
		      <div class="carousel-item active">
		        <img src="uploads/slider_images/<?php echo e($images[0]->image1_name); ?>" class="d-block w-100" alt="...">
		        <div class="carousel-caption d-none d-md-block">
		          <h5><?php echo e($images[0]->label1); ?></h5>
		          <p><?php echo e($images[0]->text1); ?></p>
		        </div>
		      </div>
		      <div class="carousel-item">
		        <img src="uploads/slider_images/<?php echo e($images[0]->image2_name); ?>" class="d-block w-100" alt="...">
		        <div class="carousel-caption d-none d-md-block">
		          <h5><?php echo e($images[0]->label2); ?></h5>
		          <p><?php echo e($images[0]->text2); ?></p>
		        </div>
		      </div>
		      <div class="carousel-item">
		        <img src="uploads/slider_images/<?php echo e($images[0]->image3_name); ?>" class="d-block w-100" alt="...">
		        <div class="carousel-caption d-none d-md-block">
		          <h5><?php echo e($images[0]->label3); ?></h5>
		          <p><?php echo e($images[0]->text3); ?></p>
		        </div>
		      </div>
		    </div>
		    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
		      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		      <span class="sr-only">Previous</span>
		    </a>
		    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
		      <span class="carousel-control-next-icon" aria-hidden="true"></span>
		      <span class="sr-only">Next</span>
		    </a>
		  	</div>
		</div>
	</section>
	<!--######## End banner Area ########-->

	<!--######## Start Latest News Area ########-->
	<section class="latest-news-area section-gap">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
					<div class="main-title text-center">
						<h1>PAKZONE CONSULTANTS (TESTING LAB)</h1>
						<p>HDIP/ORGA AUTHORIZED CNG TESTING LABORATORY FOR SAFETY RELIEF DEVICES & CALIBRATION OF GAUGES
						</p>
					</div>
				</div>
				<div class="col-md-3 offset-md-1 col-sm-3 py-5 rounded border-left">
						<h4 class="text-left">Latest News</h4>
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="p-1 border-bottom mx-auto">
                            <h5 class="text-uppercase"><?php echo e($news->news_headline); ?></h5>
                            <p><?php echo e($news->news_description); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="single-news card">
						
						<div class="card-body">
							<h4 class="card-title">
								<a href="#">
									Our Introduction
								</a>
							</h4>
							<p class="card-text"><?php echo e($images[0]->introduction); ?></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-news card">
						
						<div class="card-body">
							<h4 class="card-title">
								<a href="#">
									Our Mission
								</a>
							</h4>
							<p class="card-text"><?php echo e($images[0]->mission); ?></p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="single-news card">
						
						<div class="card-body">
							<h4 class="card-title">
								<a href="#">
									Our Vision
								</a>
							</h4>
							<p class="card-text"><?php echo e($images[0]->vision); ?></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--######## End Latest News Area ########-->

	<!--######## Start Our Offer Area ########-->
	<section class="our-offer-area section-gap">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-12">
					<div class="row">
						<div class="col-lg-3 col-md-3 mb-30">
							<div class="single-circle">
								<div class="single-item">
									<div class="progressBar progressBar--animateText" data-progress="75">
										<svg class="progressBar-contentCircle" viewBox="0 0 200 200">
											<circle transform="rotate(-90, 100, 100)" class="progressBar-background" cx="100" cy="100" r="95" />
											<circle transform="rotate(-90, 100, 100)" class="progressBar-circle" cx="100" cy="100" r="95" />
										</svg>
										<span class="progressBar-percentage progressBar-percentage-count">1.5K</span>
									</div>
								</div>
								<h4>Happy Clients</h4>
							</div>
						</div>

						<div class="col-lg-3 col-md-3 mb-30">
							<div class="single-circle">
								<div class="single-item">
									<div class="progressBar progressBar--animateText" data-progress="75">
										<svg class="progressBar-contentCircle" viewBox="0 0 200 200">
											<circle transform="rotate(-90, 100, 100)" class="progressBar-background" cx="100" cy="100" r="95" />
											<circle transform="rotate(-90, 100, 100)" class="progressBar-circle" cx="100" cy="100" r="95" />
										</svg>
										<span class="progressBar-percentage progressBar-percentage-count">10</span>
									</div>
								</div>
								<h4>Years of Experience</h4>
							</div>
						</div>

						<div class="col-lg-3 col-md-3 mb-30">
							<div class="single-circle">
								<div class="single-item">
									<div class="progressBar progressBar--animateText" data-progress="75">
										<svg class="progressBar-contentCircle" viewBox="0 0 200 200">
											<circle transform="rotate(-90, 100, 100)" class="progressBar-background" cx="100" cy="100" r="95" />
											<circle transform="rotate(-90, 100, 100)" class="progressBar-circle" cx="100" cy="100" r="95" />
										</svg>
										<span class="progressBar-percentage progressBar-percentage-count">250</span>
									</div>
								</div>
								<h4>Professionals</h4>
							</div>
						</div>

						<div class="col-lg-3 col-md-3 mb-30">
							<div class="single-circle">
								<div class="single-item">
									<div class="progressBar progressBar--animateText" data-progress="75">
										<svg class="progressBar-contentCircle" viewBox="0 0 200 200">
											<circle transform="rotate(-90, 100, 100)" class="progressBar-background" cx="100" cy="100" r="95" />
											<circle transform="rotate(-90, 100, 100)" class="progressBar-circle" cx="100" cy="100" r="95" />
										</svg>
										<span class="progressBar-percentage progressBar-percentage-count">369</span>
									</div>
								</div>
								<h4>On Going Job</h4>
							</div>
						</div>
					</div>
				</div>

				
			</div>
		</div>
	</section>
	<!--######## End Our Offer Area ########-->

	<!--######## Start Recent Completed Project Area ########-->
	
	<!--######## End Recent Completed Project Area ########-->

	<!--######## Start testimonial Area ########-->
	<section class="testimonial-area section-gap">
		<div class="container">
			<div class="row">
				<div class="active-testimonial-carusel">
					<div class="single-testimonial item d-flex flex-row">
						<div class="thumb">
							<img class="img-fluid" src="theme_assets/img/elements/user1.png" alt="">
						</div>
						<div class="desc">
							<p>
								“If you don’t like change, you’re going to like irrelevance even less.”
							</p>
							<h4 mt-30>Eric Shinseki</h4>
							<p class="mb-0">Former United States Secretary of Veterans Affairs</p>
						</div>
					</div>
					<div class="single-testimonial item d-flex flex-row">
						<div class="thumb">
							<img class="img-fluid" src="theme_assets/img/elements/user2.png" alt="">
						</div>
						<div class="desc">
							<p>
								“In the business world, the rear view mirror is always clearer than the windshield.”
							</p>
							<h4 mt-30>Warren Buffett</h4>
							<p class="mb-0">CEO of Berkshire Hathaway</p>
						</div>
					</div>
					<div class="single-testimonial item d-flex flex-row">
						<div class="thumb">
							<img class="img-fluid" src="theme_assets/img/elements/user1.png" alt="">
						</div>
						<div class="desc">
							<p>
								Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector,
								hardware.
							</p>
							<h4 mt-30>Mark Alviro Wiens</h4>
							<p class="mb-0">CEO at Google</p>
						</div>
					</div>
					<div class="single-testimonial item d-flex flex-row">
						<div class="thumb">
							<img class="img-fluid" src="theme_assets/img/elements/user2.png" alt="">
						</div>
						<div class="desc">
							<p>
								Accessories Here you can find the best computer accessory for your laptop, monitor, printer, scanner, speaker, projector,
								hardware.
							</p>
							<h4 mt-30>Lina Harrington</h4>
							<p class="mb-0">CEO at Google</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--######## End testimonial Area ########-->

	<!--######## Start Latest Blog Area ########-->
	
	<!--######## End Latest Blog Area ########-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>