<?php $__env->startSection('title', 'Our Expertise'); ?>
<?php $__env->startSection('content'); ?>

	<!--######## start banner Area ########-->
	<section style="background-image: url( <?php echo e(asset('office-1209640_1920.jpg')); ?> ); background-size: cover;
    position: relative;">
		<div class="container">
			<div class="row d-flex align-items-center justify-content-center">
				<div class="about-content col-lg-12">
					<h1 class="text-white text-uppercase">
						Our Expertise
					</h1>
					<p class="text-white link-nav"><a href="/">Home </a> <span class="lnr lnr-arrow-right"></span> <a href="/our_expertise">
							Our Expertise</a></p>
				</div>
			</div>
		</div>
	</section>
	<!--######## End banner Area ########-->

	<!--######## Start Latest News Area ########-->
	<section class="latest-news-area mt-5">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="main-title text-center col-10">
						<h1>Our Expertise</h1>
							Pakzone Consultants technical resources include highly qualified and experienced consultants with excellent track record in the following fields.
						<div class="row">
							<div class="col-3"></div>
							<div class="col-6">
								<ul class="list-group text-left">
									<li class="list-group-item">Bussiness development</li>
									<li class="list-group-item">Women in development</li>
									<li class="list-group-item">Technology transfer</li>
									<li class="list-group-item">Rural Development</li>
									<li class="list-group-item">Corporate Strategies</li>
									<li class="list-group-item">Agriculture and agro Based industries</li>
									<li class="list-group-item">Micro enterprises</li>
									<li class="list-group-item">Training and research</li>
								</ul>
							</div>
						</div>
						
					</div>
					<div class="main-title text-center col-10">
						<h1>Turn-Key solutions</h1>
							The Pakzone Consultants will provide turn-key solution, and will provide following services:-
						<div class="row">
							<div class="col-3"></div>
							<div class="col-6">
								<ul class="list-group text-left">
									<li class="list-group-item">Incorporation of the firm</li>
									<li class="list-group-item">Complete bank procedure</li>
									<li class="list-group-item">complete L/C formalities on behalf of client</li>
									<li class="list-group-item">Get NTN number for the project</li>
									<li class="list-group-item">Complete procedure for sales tax registration</li>
									<li class="list-group-item">Provide extra services to complete book of accounts for sales tax</li>
									<li class="list-group-item">Complete formalities for chamber of commerce membership</li>
									<li class="list-group-item">Registration with EBP</li>
									<li class="list-group-item">Will obtain CNG license from Ministry of Petroleum, Islamabad</li>
									<li class="list-group-item">Acquisition ofequipment from supplier</li>

									<li class="list-group-item">Get approval from high way dept</li>
									<li class="list-group-item">Get approval from from Explosive dept</li>
									<li class="list-group-item">Get approval from from EPA</li>
									<li class="list-group-item">Get approval from Cantt board</li>
									<li class="list-group-item">Get approval from police dept</li>
									<li class="list-group-item">Get approval from local authority</li>
									<li class="list-group-item">Get approval from Building control agency</li>
									<li class="list-group-item">Complete formalities for license from Ministry ofPetroleum such as Feasibility with market, Technical & Financial aspects</li>
									<li class="list-group-item">Affidavit for not to install cng station at petrol pump</li>
									<li class="list-group-item">Affidavit in favour ofHigh way/cant/PDA</li>

									<li class="list-group-item">affidavit for safety precautions</li>
									<li class="list-group-item">List of trained staff</li>
								</ul>
							</div>
						</div>
						
					</div>
				</div>
			</div>
			
		</div>
	</section>
	<!--######## End Latest News Area ########-->

	<!--######## Start Our Offer Area ########-->
	
	<!--######## End Our Offer Area ########-->

	<!--######## Start testimonial Area ########-->
	
	<!--######## End testimonial Area ########-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>