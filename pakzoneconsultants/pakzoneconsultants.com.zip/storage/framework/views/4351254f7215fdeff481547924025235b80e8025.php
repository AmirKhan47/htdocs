<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Users
        
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title"> Edit User</h3>
            </div>
            <div class="box-body">
                <form class="form-horizontal" method="POST" action="/admin/update_user" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="admin_id" value="<?php echo e($data->admin_id); ?>">
                    <div class="box-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session()->get('success')): ?>
                            <div class="alert alert-info">
                                <?php echo e(session()->get('success')); ?>  
                            </div><br />
                        <?php endif; ?>
                        <div class="form-group">
                          <label for="" class="col-sm-2 control-label">Name</label>

                          <div class="col-sm-10">
                            <input type="text" name="name" value="<?php echo e($data->name); ?>" class="form-control" placeholder="Name" required="required">
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="" class="col-sm-2 control-label">Email</label>

                          <div class="col-sm-10">
                            <input type="email" name="email" value="<?php echo e($data->email); ?>" class="form-control" placeholder="Email" required="required">
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="" class="col-sm-2 control-label">Username</label>

                          <div class="col-sm-10">
                            <input type="text" name="username" value="<?php echo e($data->username); ?>" class="form-control" placeholder="Username" required="required">
                          </div>
                        </div>
                        <div class="form-group">
                          <label for="" class="col-sm-2 control-label">Password</label>

                          <div class="col-sm-10">
                            <input type="password" name="password" value="<?php echo e($data->password); ?>" class="form-control" placeholder="Password" required="required">
                          </div>
                        </div>
                        
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer">
                        <button type="submit" name="submit" value="submit" class="btn btn-info pull-right">Submit</button>
                    </div>
                    <!-- /.box-footer -->
                </form>
            </div>
          </div>
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>