<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Home Page
        
      </h1>
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-12">
          <!-- Horizontal Form -->
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Home Page Settings</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
                <div class="box-body">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if(session()->get('success')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('success')); ?>  
                        </div><br />
                    <?php endif; ?>

                    <div class="row">

                        <div class="col-md-4">
                            <form method="POST" action="/admin/home">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="image_id" value="<?php echo e($images[0]['image_id']); ?>">
                                <div class="form-group">
                                    <label for="">Introduction</label>
                                    <textarea class="form-control" rows="5" name="introduction" required="required"><?php echo e($images[0]['introduction']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Mission</label>
                                    <textarea class="form-control" rows="5" name="mission" required="required"><?php echo e($images[0]['mission']); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="">Vision</label>
                                    <textarea class="form-control" rows="5" name="vision" required="required"><?php echo e($images[0]['vision']); ?></textarea>
                                </div>
                                <button type="submit" name="submit" value="submit" class="btn btn-info">
                                    Submit
                                </button>
                            </form>
                        </div>

                    </div>

                </div>
                <!-- /.box-body -->
                
                <!-- /.box-footer -->
            
          </div>
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>