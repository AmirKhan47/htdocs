<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $fillable = [
    'image1_name',
    'image2_name',
    'image3_name',
  ];
}
